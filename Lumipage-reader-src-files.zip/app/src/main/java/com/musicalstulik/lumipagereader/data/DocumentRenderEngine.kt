package com.musicalstulik.lumipagereader.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import java.io.Closeable
import java.io.File

class DocumentRenderEngine private constructor(
    private val pdfEngine: PdfRenderEngine?,
    private val textEngine: TextDocRenderEngine?
) : Closeable {

    val pageCount: Int
        get() = pdfEngine?.pageCount ?: textEngine?.pageCount ?: 0

    val fileName: String
        get() = pdfEngine?.fileName ?: textEngine?.fileName ?: "Document"

    val uri: Uri
        get() = pdfEngine?.uri ?: textEngine?.uri ?: Uri.EMPTY

    val isEditableTextDocument: Boolean
        get() = textEngine != null

    suspend fun renderPage(pageIndex: Int, targetWidthPx: Int, scale: Float = 1.0f): Bitmap? {
        return pdfEngine?.renderPage(pageIndex, targetWidthPx, scale)
            ?: textEngine?.renderPage(pageIndex, targetWidthPx, scale)
    }

    fun getPageAspectRatio(pageIndex: Int): Float {
        return pdfEngine?.getPageAspectRatio(pageIndex)
            ?: textEngine?.getPageAspectRatio(pageIndex)
            ?: 1.414f
    }

    fun getRawText(context: Context): String {
        val currentEngine = textEngine ?: return ""
        return try {
            if (currentEngine.isDocx) {
                DocxTextParser.parseDocx(context, uri).joinToString("\n\n")
            } else {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                } ?: ""
            }
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    fun saveRawText(context: Context, newText: String): Boolean {
        if (textEngine == null) return false
        return try {
            context.contentResolver.openOutputStream(uri, "wt")?.use { outputStream ->
                outputStream.write(newText.toByteArray(Charsets.UTF_8))
                outputStream.flush()
                true
            } ?: false
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    override fun close() {
        pdfEngine?.close()
        textEngine?.close()
    }

    companion object {
        fun create(context: Context, uri: Uri): DocumentRenderEngine {
            val fileName = resolveFileName(context, uri).lowercase()
            val mimeType = context.contentResolver.getType(uri)?.lowercase() ?: ""

            if (fileName.endsWith(".docx") || mimeType.contains("wordprocessingml") || mimeType.contains("msword")) {
                val textEngine = TextDocRenderEngine(context, uri, isDocx = true)
                return DocumentRenderEngine(pdfEngine = null, textEngine = textEngine)
            }

            if (fileName.endsWith(".txt") || fileName.endsWith(".log") || fileName.endsWith(".md") ||
                fileName.endsWith(".csv") || fileName.endsWith(".json") || fileName.endsWith(".xml") ||
                mimeType.startsWith("text/") || mimeType.contains("plain")) {
                val textEngine = TextDocRenderEngine(context, uri, isDocx = false)
                return DocumentRenderEngine(pdfEngine = null, textEngine = textEngine)
            }

            return try {
                val pdfEngine = PdfRenderEngine(context, uri)
                DocumentRenderEngine(pdfEngine = pdfEngine, textEngine = null)
            } catch (e: Exception) {
                val textEngine = TextDocRenderEngine(context, uri, isDocx = false)
                DocumentRenderEngine(pdfEngine = null, textEngine = textEngine)
            }
        }

        private fun resolveFileName(context: Context, uri: Uri): String {
            if (uri.scheme == "content") {
                try {
                    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1 && cursor.moveToFirst()) {
                            val name = cursor.getString(nameIndex)
                            if (!name.isNullOrBlank()) return name
                        }
                    }
                } catch (e: Exception) {
                    // Fallback
                }
            } else if (uri.scheme == "file") {
                val path = uri.path
                if (path != null) {
                    val file = File(path)
                    if (file.name.isNotBlank()) return file.name
                }
            }
            return uri.lastPathSegment ?: "Document"
        }
    }
}
