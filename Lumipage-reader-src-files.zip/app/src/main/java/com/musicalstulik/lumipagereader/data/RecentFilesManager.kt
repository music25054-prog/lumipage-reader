package com.musicalstulik.lumipagereader.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class RecentPdfItem(
    val uriString: String,
    val fileName: String,
    val lastPage: Int = 0,
    val totalPages: Int = 0,
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
) {
    val uri: Uri get() = Uri.parse(uriString)
}

class RecentFilesManager(context: Context) {

    private val prefs = context.getSharedPreferences("lumipagereader_recent_files", Context.MODE_PRIVATE)

    fun getRecentFiles(): List<RecentPdfItem> {
        val jsonString = prefs.getString(KEY_RECENT_LIST, null) ?: return emptyList()
        val list = mutableListOf<RecentPdfItem>()
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    RecentPdfItem(
                        uriString = obj.getString("uri"),
                        fileName = obj.optString("fileName", "Document"),
                        lastPage = obj.optInt("lastPage", 0),
                        totalPages = obj.optInt("totalPages", 0),
                        isFavorite = obj.optBoolean("isFavorite", false),
                        timestamp = obj.optLong("timestamp", 0)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list.sortedByDescending { it.timestamp }
    }

    fun addOrUpdateRecentFile(uri: Uri, fileName: String, totalPages: Int, lastPage: Int = 0) {
        val current = getRecentFiles().toMutableList()
        val uriStr = uri.toString()
        val existing = current.firstOrNull { it.uriString == uriStr }
        val wasFavorite = existing?.isFavorite ?: false
        
        // Remove existing if present
        current.removeAll { it.uriString == uriStr }
        
        // Add to top
        current.add(
            0,
            RecentPdfItem(
                uriString = uriStr,
                fileName = fileName,
                lastPage = lastPage,
                totalPages = totalPages,
                isFavorite = wasFavorite,
                timestamp = System.currentTimeMillis()
            )
        )

        // Keep maximum 20 recent items
        val trimmed = current.take(20)
        saveList(trimmed)
    }

    fun toggleFavorite(uriString: String) {
        val current = getRecentFiles().toMutableList()
        val index = current.indexOfFirst { it.uriString == uriString }
        if (index != -1) {
            val item = current[index]
            current[index] = item.copy(isFavorite = !item.isFavorite)
            saveList(current)
        }
    }

    fun updateLastPage(uri: Uri, lastPage: Int) {
        val current = getRecentFiles().toMutableList()
        val uriStr = uri.toString()
        val index = current.indexOfFirst { it.uriString == uriStr }
        if (index != -1) {
            val item = current[index]
            current[index] = item.copy(lastPage = lastPage, timestamp = System.currentTimeMillis())
            saveList(current)
        }
    }

    fun removeRecentFile(uriString: String) {
        val current = getRecentFiles().toMutableList()
        current.removeAll { it.uriString == uriString }
        saveList(current)
    }

    fun clearAll() {
        prefs.edit().remove(KEY_RECENT_LIST).apply()
    }

    private fun saveList(list: List<RecentPdfItem>) {
        try {
            val jsonArray = JSONArray()
            for (item in list) {
                val obj = JSONObject().apply {
                    put("uri", item.uriString)
                    put("fileName", item.fileName)
                    put("lastPage", item.lastPage)
                    put("totalPages", item.totalPages)
                    put("isFavorite", item.isFavorite)
                    put("timestamp", item.timestamp)
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString(KEY_RECENT_LIST, jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        private const val KEY_RECENT_LIST = "recent_pdf_list"
    }
}
