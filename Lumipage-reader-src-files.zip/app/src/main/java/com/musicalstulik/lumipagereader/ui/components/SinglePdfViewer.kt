package com.musicalstulik.lumipagereader.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.musicalstulik.lumipagereader.R
import com.musicalstulik.lumipagereader.data.DrawPath
import com.musicalstulik.lumipagereader.data.DrawingTool
import com.musicalstulik.lumipagereader.data.MarginNote
import com.musicalstulik.lumipagereader.data.ReaderTheme

@Composable
fun SinglePdfViewer(
    pageCount: Int,
    currentPage: Int,
    zoomScale: Float,
    renderPage: suspend (pageIndex: Int, targetWidthPx: Int, scale: Float) -> Bitmap?,
    getPageAspectRatio: (pageIndex: Int) -> Float,
    onNextPage: () -> Unit,
    onPreviousPage: () -> Unit,
    marginNotes: List<MarginNote> = emptyList(),
    onDeleteNote: (String) -> Unit = {},
    isDrawingMode: Boolean = false,
    drawingTool: DrawingTool = DrawingTool.HIGHLIGHTER,
    selectedColor: Color = Color(0xFFFFEB3B),
    selectedStrokeWidth: Float = 32f,
    pageDrawings: Map<Int, List<DrawPath>> = emptyMap(),
    onAddDrawPath: (Int, DrawPath) -> Unit = { _, _ -> },
    readerTheme: ReaderTheme = ReaderTheme.LIGHT,
    modifier: Modifier = Modifier
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var userScale by remember { mutableFloatStateOf(1f) }

    val effectiveScale = zoomScale * userScale

    val panGestureModifier = if (!isDrawingMode) {
        Modifier.pointerInput(currentPage) {
            detectTransformGestures { _, pan, zoom, _ ->
                userScale = (userScale * zoom).coerceIn(0.8f, 4.0f)
                if (effectiveScale > 1.05f) {
                    offsetX += pan.x
                    offsetY += pan.y
                } else {
                    offsetX = 0f
                    offsetY = 0f
                }
            }
        }
    } else {
        Modifier
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .then(panGestureModifier),
        contentAlignment = Alignment.Center
    ) {
        val density = LocalDensity.current
        val containerWidth = maxWidth
        val containerHeight = maxHeight
        val widthPx = with(density) { containerWidth.roundToPx() }
        val aspectRatio = remember(currentPage) { getPageAspectRatio(currentPage) } // height / width

        val pageAspectRatio = 1.0f / aspectRatio
        val containerAspectRatio = if (containerHeight > 0.dp) containerWidth / containerHeight else 1f

        val sizingModifier = if (pageAspectRatio > containerAspectRatio) {
            Modifier.fillMaxWidth().aspectRatio(pageAspectRatio)
        } else {
            Modifier.fillMaxHeight().aspectRatio(pageAspectRatio)
        }

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .then(sizingModifier)
                    .graphicsLayer(
                        scaleX = effectiveScale,
                        scaleY = effectiveScale,
                        translationX = offsetX,
                        translationY = offsetY
                    ),
                contentAlignment = Alignment.Center
            ) {
                PdfPageCard(
                    pageIndex = currentPage,
                    targetWidthPx = widthPx,
                    aspectRatio = aspectRatio,
                    renderPage = renderPage,
                    scale = 1.0f,
                    pageNotes = marginNotes.filter { it.pageIndex == currentPage },
                    onDeleteNote = onDeleteNote,
                    isDrawingMode = isDrawingMode,
                    drawingTool = drawingTool,
                    selectedColor = selectedColor,
                    selectedStrokeWidth = selectedStrokeWidth,
                    drawings = pageDrawings[currentPage] ?: emptyList(),
                    onAddDrawPath = { path -> onAddDrawPath(currentPage, path) },
                    readerTheme = readerTheme,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Edge Navigation Buttons
            if (currentPage > 0 && !isDrawingMode) {
                IconButton(
                    onClick = {
                        offsetX = 0f
                        offsetY = 0f
                        userScale = 1f
                        onPreviousPage()
                    },
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(start = 8.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.previous_page),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (currentPage < pageCount - 1 && !isDrawingMode) {
                IconButton(
                    onClick = {
                        offsetX = 0f
                        offsetY = 0f
                        userScale = 1f
                        onNextPage()
                    },
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 8.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = stringResource(R.string.next_page),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
